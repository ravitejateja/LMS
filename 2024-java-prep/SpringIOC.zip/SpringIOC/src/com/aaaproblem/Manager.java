package com.aaaproblem;

public class Manager {
//private TL tl;
	
public void dowork() {
		System.out.println("Manager Started working");
		TL tl=new TL();
		tl.dowork();
	}
}
