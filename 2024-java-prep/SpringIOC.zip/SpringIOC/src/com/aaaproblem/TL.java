package com.aaaproblem;

public class TL {
	
	public void dowork() {
		System.out.println("TL Started working");
		Developer d=new Developer();
		d.dowork();
	}

}
