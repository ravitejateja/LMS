package com.aaaproblem;

public class Developer {
	
public void dowork() {
		System.out.println("developer strated working");
	}
}
