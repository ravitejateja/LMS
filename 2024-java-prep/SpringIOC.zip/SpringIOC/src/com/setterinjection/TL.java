package com.setterinjection;

public class TL {
	
private Developer dev;

public Developer getDev() {
	return dev;
}

public void setDev(Developer dev) {
	this.dev = dev;
}

public void dowork() {
	System.out.println("TL started working using setter injection");
	dev.dowork();
}

}
