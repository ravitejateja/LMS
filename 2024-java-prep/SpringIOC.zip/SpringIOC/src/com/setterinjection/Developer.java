package com.setterinjection;

public class Developer {
	
	public void dowork() {
		System.out.println("developer strated working using setter injection");
	}

}
