package com.setterinjection;

public class Manager {
	
private TL tl;
	
	
public TL getTl() {
	return tl;
}


public void setTl(TL tl) {
	this.tl = tl;
}


public void dowork() {
	System.out.println("Manager started working using setter injection");
	tl.dowork();
}
}
