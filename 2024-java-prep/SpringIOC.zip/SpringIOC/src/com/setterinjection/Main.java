package com.setterinjection;

public class Main {
	
	public static void main(String[] args) {
		
		Developer dev=new Developer();
		TL tl=new TL();
		tl.setDev(dev);
		Manager man=new Manager();
		man.setTl(tl);
		
		man.dowork();
		
	}

}
