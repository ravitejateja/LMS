package com.teja.spring.setterinjection;

public class Manager {
	
private TL tl;

private String company;
	

public TL getTl() {
	return tl;
}


public void setTl(TL tl) {
	this.tl = tl;
}


public String getCompany() {
	return company;
}


public void setCompany(String company) {
	this.company = company;
}


public void dowork() {
	System.out.println("Manager started working using setter injection");
	tl.dowork();
	
}
}
