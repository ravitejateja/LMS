package com.teja.spring.setterinjection;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Main {
	
	public static void main(String[] args) {
		 Resource resource=new ClassPathResource("setter-injection-spring.xml");  
		    BeanFactory factory=new XmlBeanFactory(resource);  
		    
		      // ApplicationContext context=new ClassPathXmlApplicationContext("setter-injection-spring.xml");  
			  // Manager managerapp=  (Manager) context.getBean("mymanager");
			  // managerapp.dowork();
		    
		    Manager manager=(Manager)factory.getBean("mymanager");  
		    manager.dowork();  
		  //  Manager manager2=(Manager)factory.getBean("mymanager");  
		    
		   // System.out.println(manager);
		   // System.out.println(manager2);
		   // System.out.println(manager.getCompany());
		   
		    
		  
		
	}

}
