package com.teja.spring.autowire;

public class Developer {
	
	public void dowork() {
		System.out.println("developer strated working using autowire");
	}

}
