package com.teja.spring.autowire;

public class TL {
	
private Developer dev;

//Enable this constructor when you use  autowire by constructor
/*
 * public TL(Developer dev) {
 * 
 * this.dev = dev; }
 */

public Developer getDev() {
	return dev;
}

public void setDev(Developer dev) {
	this.dev = dev;
}

public void dowork() {
	System.out.println("TL started working using autowire");
	dev.dowork();
}

}
