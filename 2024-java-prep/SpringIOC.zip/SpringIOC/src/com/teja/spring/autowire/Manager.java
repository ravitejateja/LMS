package com.teja.spring.autowire;

public class Manager {
		
private TL tl;

//Enable this constructor when you use  autowire by constructor
/*
 * public Manager(TL tl) {
 * 
 * this.tl = tl; }
 */


public TL getTl() {
	return tl;
}


public void setTl(TL tl) {
	this.tl = tl;
}



public void dowork() {
	System.out.println("Manager started working using autowire");
	tl.dowork();
	
}
}
