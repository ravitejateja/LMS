package com.teja.spring.construtorinjection;

public class Manager {
	
private TL tl;

private String company;
	


public Manager(TL tl, String company) {
	this.tl = tl;
	this.company = company;
}



public void dowork() {
	System.out.println(company);
	System.out.println("Manager started working using constructor injection");
	tl.dowork();
	
}
}
