package com.teja.spring.construtorinjection;

public class Developer {
	public Developer() {}
	
	public void dowork() {
		System.out.println("developer strated working using constructor injection");
	}

}
