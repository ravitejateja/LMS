package com.teja.spring.construtorinjection;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Main {
	
	public static void main(String[] args) {
		 Resource resource=new ClassPathResource("constructor-injection-spring.xml");  
		   BeanFactory factory=new XmlBeanFactory(resource);   
		    Manager manager=(Manager) factory.getBean("mymanager");  
		    manager.dowork(); 
		    
		    ApplicationContext context=new ClassPathXmlApplicationContext("constructor-injection-spring.xml");  
			   Manager managerapp=  (Manager) context.getBean("mymanager");
			   managerapp.dowork(); 
		
	}

}
