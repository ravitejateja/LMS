package com.teja.spring.construtorinjection;

public class TL {
	
private Developer dev;


public TL(Developer dev) {
	this.dev = dev;
}


public void dowork() {
	System.out.println("TL started working using constructor injection");
	dev.dowork();
}

}
