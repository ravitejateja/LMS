package com.teja.spring.noxml.annotaions;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Manager {

	@Autowired
	private TL tl;

	public void dowork() {

		System.out.println("Manager started working using setter injection");
		tl.dowork();
	}
}
