package com.teja.spring.noxml.annotaions;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class TL {
	
@Autowired	
private Developer dev;



public void dowork() {
	System.out.println("TL started working using setter injection");
	dev.dowork();
}

}
