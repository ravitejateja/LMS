package com.teja.spring.noxml.annotaions;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

@ComponentScan
@PropertySource("classpath:mydb.properties")
//@ComponentScan({"com.javaprogramto.packagee.one", "com.javaprogramto.packagee.two"})
public class Main {

	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(Main.class);
		   Manager man = (Manager) context.getBean("manager");
		Object o=new Object();
		
		    man.dowork();
		
	}
	
	

}
