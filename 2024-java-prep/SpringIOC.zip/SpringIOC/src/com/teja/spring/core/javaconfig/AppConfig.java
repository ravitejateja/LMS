package com.teja.spring.core.javaconfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
	@Bean
	public Manager manager() {

		return new Manager();
	}

	@Bean
	public TL tl() {

		return new TL();
	}

	@Bean
	public Developer dev() {

		return new Developer();
	}
}
