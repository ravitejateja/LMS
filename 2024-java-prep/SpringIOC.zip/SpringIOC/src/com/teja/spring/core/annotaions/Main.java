package com.teja.spring.core.annotaions;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class Main {
	
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("annotaionscan.xml");
        Manager man = (Manager) context.getBean("manager");
		
		man.dowork();
		
	}
	
	

}
