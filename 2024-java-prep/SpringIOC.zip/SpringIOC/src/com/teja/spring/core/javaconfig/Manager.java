package com.teja.spring.core.javaconfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

//@Component
public class Manager {
	
@Autowired	
private TL tl;
	

public void dowork() {
	System.out.println("Manager started working using javaconfig ");
	tl.dowork();
}
}
