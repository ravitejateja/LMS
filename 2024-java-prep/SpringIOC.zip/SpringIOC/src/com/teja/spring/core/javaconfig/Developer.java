package com.teja.spring.core.javaconfig;

import org.springframework.stereotype.Component;

//@Component
public class Developer {
	
	public void dowork() {
		System.out.println("developer strated working using javaconfig ");
	}

}
