package com.teja.spring.core.properties;

import java.sql.Connection;
import java.sql.DriverManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component
public class Mydatabase {
	
	@Autowired
	Environment env;
	
	@Value("${TEJA_DB_URL}")
    String proptesturl;
	
	@Bean
	public Connection getconnection() {
		Connection con=null;
		try{
			Class.forName(env.getProperty("TEJA_DB_DRIVER_CLASS"));
			con=DriverManager.getConnection(env.getProperty("TEJA_DB_URL"),env.getProperty("TEJA_DB_USERNAME"),env.getProperty("TEJA_DB_PASSWORD"));
			
			System.out.println("test url::"+proptesturl);
		}catch(Exception e){System.out.println(e);}
	
		
		return con;
		
	}

}
