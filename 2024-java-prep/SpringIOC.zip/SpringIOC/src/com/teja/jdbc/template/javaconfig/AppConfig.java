package com.teja.jdbc.template.javaconfig;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
@PropertySource("classpath:mydb.properties")
@ComponentScan
public class AppConfig {

	@Autowired
	private Environment env;

	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		
	    MyJDBCCrud crud= (MyJDBCCrud) context.getBean("myJDBCCrud");
	    crud.crudoperations();
	    
		//Below code is just for testing to get all beans created by applicationContext
		//context.getBean(MyJDBCCrud.class);
		/* String[] allBeanNames = context.getBeanDefinitionNames();
        for(String beanName : allBeanNames) {
            System.out.println(beanName);
        } */
	}

	@Bean
	public DataSource dataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(env.getProperty("TEJA_DB_DRIVER_CLASS"));
		dataSource.setUrl(env.getProperty("TEJA_DB_URL"));
		dataSource.setUsername(env.getProperty("TEJA_DB_USERNAME"));
		dataSource.setPassword(env.getProperty("TEJA_DB_PASSWORD"));
		return dataSource;
	}

	@Bean
	public JdbcTemplate jdbcTemplate(DataSource dataSource) {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		jdbcTemplate.setResultsMapCaseInsensitive(true);
		return jdbcTemplate;
	}

}
