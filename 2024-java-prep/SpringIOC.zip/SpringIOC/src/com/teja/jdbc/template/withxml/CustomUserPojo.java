package com.teja.jdbc.template.withxml;

public class CustomUserPojo {
	private Integer myid;
	private String myname;
	private String mypassword;
	private String myemail;
	private String mycountry;
	public Integer getMyid() {
		return myid;
	}
	public void setMyid(Integer myid) {
		this.myid = myid;
	}
	public String getMyname() {
		return myname;
	}
	public void setMyname(String myname) {
		this.myname = myname;
	}
	public String getMypassword() {
		return mypassword;
	}
	public void setMypassword(String mypassword) {
		this.mypassword = mypassword;
	}
	public String getMyemail() {
		return myemail;
	}
	public void setMyemail(String myemail) {
		this.myemail = myemail;
	}
	public String getMycountry() {
		return mycountry;
	}
	public void setMycountry(String mycountry) {
		this.mycountry = mycountry;
	}
	
	
	

}
