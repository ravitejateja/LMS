package com.teja.jdbc.template.withxml;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class MyJDBCCrud {
	@Autowired
	JdbcTemplate jdbcTemplate;
	

public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

public void crudoperations() {
	UserPojo u=new UserPojo();
	u.setId(4);
	u.setName("tejaspringjava");
	u.setPassword("teja");
	u.setEmail("teja@spring.com");
	u.setCountry("india");
	
	//savedata(u);
	//updatedata(u);
	//delete(u);
	getall();
	//getallByCustom();
	
}

private void getall() {
	String SELECT_QUERY="select * from user";
	List<UserPojo> list=jdbcTemplate.query(SELECT_QUERY, new BeanPropertyRowMapper(UserPojo.class));
	
	for(UserPojo up:list) {
		System.out.println(up.getId() +"  "+ up.getName() +"  " +up.getPassword()+" "+ up.getEmail() +" " +up.getCountry());
	}
	
}

private void getallByCustom() {
	String SELECT_QUERY="select * from user";
List<CustomUserPojo> list=jdbcTemplate.query(SELECT_QUERY, new CustomUserRowMapper());
	
	for(CustomUserPojo up:list) {
		System.out.println(up.getMyid()+"  "+ up.getMyname()+"  " +up.getMypassword()+" "+ up.getMyemail()+" " +up.getMycountry());
	}
	
	/*
	 * List<CustomUserPojo> list=jdbcTemplate.query(SELECT_QUERY, new
	 * BeanPropertyRowMapper(CustomUserPojo.class));
	 * 
	 * for(CustomUserPojo up:list) { System.out.println(up.getMyid()+"  "+
	 * up.getMyname()+"  " +up.getMypassword()+" "+ up.getMyemail()+" "
	 * +up.getMycountry()); }
	 */
	
}

private void delete(UserPojo u) {
	String DELETE_QUERY="delete from user where id=?";
	int i=jdbcTemplate.update(DELETE_QUERY,u.getId());
	if(i>0) {
		System.out.println("data deleted sucessfully");
	}	
	else {
		System.out.println("data not deleted ");
	}

	
}

private void updatedata(UserPojo u) {
	String UPDATE_QUERY="update user set name=? where id=?";
	int i=jdbcTemplate.update(UPDATE_QUERY, u.getName(),u.getId());
	if(i>0) {
		System.out.println("data updated sucessfully");
	}	
	else {
		System.out.println("data not updated ");
	}

	
}

private void savedata(UserPojo u) {
	String INSERT_QUERY="insert into user (name,password,email,country) values(?,?,?,?)";
	
	int i=jdbcTemplate.update(INSERT_QUERY, u.getName(),u.getPassword(),u.getEmail(),u.getCountry());
		if(i>0) {
			System.out.println("data inserted sucessfully");
		}	
		else {
			System.out.println("data not inserted ");
		}
	
}
}
