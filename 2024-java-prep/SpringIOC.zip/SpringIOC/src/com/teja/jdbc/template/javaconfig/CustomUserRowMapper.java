package com.teja.jdbc.template.javaconfig;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class CustomUserRowMapper implements RowMapper<CustomUserPojo> {

	@Override
	public CustomUserPojo mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		CustomUserPojo user=new CustomUserPojo();
		user.setMyid(rs.getInt(1));
		user.setMyname(rs.getString(2));
		user.setMypassword(rs.getString(3));
		user.setMyemail(rs.getString(4));
		user.setMycountry(rs.getString(5));
		return user;
	}

}
