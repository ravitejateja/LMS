package com.constructor;

public class Main {
	
	public static void main(String[] args) {
		Developer dev=new Developer();
		TL tl=new TL(dev);
		Manager man=new Manager(tl);
		man.dowork();
	}
	

}
