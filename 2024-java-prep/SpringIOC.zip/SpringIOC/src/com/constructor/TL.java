package com.constructor;

public class TL {
	private Developer dev;

	public TL(Developer dev) {
		
		this.dev = dev;
	}
	public void dowork() {
		System.out.println("TL strated working  using constructor injection");
		dev.dowork();
	}
	

}
