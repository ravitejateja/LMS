package com.constructor;

public class Manager {
	
	private TL tl;

	public Manager(TL tl) {
		
		this.tl = tl;
	}
	
	public void dowork() {
		System.out.println("manager strated workingn using constructor injection");
		tl.dowork();
	}
	
	

}
