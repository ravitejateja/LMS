package com.constructor;

public class Developer {
	
	public void dowork() {
		System.out.println("Developer strated working using constructor injection");
	}

}
