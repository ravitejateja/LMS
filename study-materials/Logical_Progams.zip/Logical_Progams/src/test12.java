import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class test12 
{

	public static void main(String[] args) 
	{
		String alphabets="a,b,c,d,e";
		String str="12a3b4c";
		
		str.chars().mapToObj(n->(char)c).filter(c->alphabets.indexOf(c)>=0).collect(Collectors.summarizingInt(c));
		String specialCharacters = "!@#$%^&*()_+{}|:<>?~`-=[]\\;',./\"";
        String str="abg@@%dodkk%&@s";
        
         Map<Character, Long> str1 = str.chars()
                                        .mapToObj(n->(char)n)
                                        .filter(c->specialCharacters.indexOf(c)>=0)
                                        .collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
         
                  System.out.println(str1);
	}    

	}

}
