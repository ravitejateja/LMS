public class SingletonDemo
{

	public static void main(String[] args)
	{
		SingletonEagerIntialization obj1= SingletonEagerIntialization.getInstance();
		SingletonEagerIntialization obj2=SingletonEagerIntialization.getInstance();
		if (obj1==obj2)
		{
			System.out.println("Both objects ae same instance for Eager Intialization");
		}
		
		
		SingletonLazyIntialization obj3= SingletonLazyIntialization.getInstance();
		SingletonLazyIntialization obj4= SingletonLazyIntialization.getInstance();
		if(obj3==obj4)
		{
			System.out.println("Both Objects are same for Lazy Intialization");
		}
	   	
	}

}
