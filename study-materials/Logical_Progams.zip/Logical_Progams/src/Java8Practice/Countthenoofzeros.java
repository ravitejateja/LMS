package Java8Practice;

public class Countthenoofzeros
{

	public static void main(String[] args)
	{
		String str= "01-12-1990";
		String number="00000100110010011100";
		long count=number.chars().filter(e->(char)e=='0').count();
		System.out.println(count);

	}

}
