package Java8Practice;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import InterviewRealTimeByJava8.Employee;

public class filterObjectsofPrice
{

	   int id;
	   String name;
	   double price;
	public filterObjectsofPrice(int id, String name, double price)
	{
		this.id=id;
		this.price=price;
		this.name=name;
	}
	   
	public static void main(String[] args)
	{
          	  List<filterObjectsofPrice> list= new ArrayList<>();
          	  List<filterObjectsofPrice> list1= new ArrayList<>();
          	  list.add(new filterObjectsofPrice(1, "Siva", 12340));
           	  list.add(new filterObjectsofPrice(2, "Sekhar", 345600));
              list.add(new filterObjectsofPrice(3, "Jasvik", 323451));
          	  list.add(new filterObjectsofPrice(4, "Nandu", 123490));
          	  list.add(new filterObjectsofPrice(5, "Sree", 13456));
          	  list.add(new filterObjectsofPrice(6, "Abhai", 123498));
          	
          	   list.stream().filter(i->i.price>10000).forEach(i->System.out.println(i.price));
          	 
         	
	}

}
