package Java8Practice;

import java.util.Arrays;
import java.util.List;

public class lengthOfString 
{

	public static void main(String[] args)
	{
	    List<String> Vehicles = Arrays.asList("tvs","Suzuki","Maruti" ,"Bajaj" ,"Yamaha","Elon");
	    Vehicles.stream().map(vname->vname.length()).forEach(length->System.out.println(length));;
	    for(String name: Vehicles)
		{
	    	System.out.println( name  +  " ==>  " +   name.length());
		}
		
       
	}

}
