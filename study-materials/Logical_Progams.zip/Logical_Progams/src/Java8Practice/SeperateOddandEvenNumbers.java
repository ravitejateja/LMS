package Java8Practice;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;

public class SeperateOddandEvenNumbers 
{

	public static void main(String[] args) 
	{
		List<Integer> listofintegers=Arrays.asList(12,14,21,34,56,8,98,93,25,67,89);
		Map<Boolean, List<Integer>> oddEvenNumbersMap=listofintegers. stream().collect(Collectors.partitioningBy(i->i%2==0));
        Set<Entry<Boolean,List<Integer>>> entryset= oddEvenNumbersMap.entrySet();
        for(Entry<Boolean, List<Integer>> entry : entryset)
        {
        	System.out.println("____________________");
        	if(entry.getKey())
        	{
        		System.out.println("Even numbers");
        	}
        	else
        	{
        		System.out.println("Odd Numbers");
        	}
        	System.out.println("______________________");
        	List<Integer> list=entry.getValue();
        	for(int i: list)
        	{
        		System.out.println(i);
        	}
        }
	}

}
