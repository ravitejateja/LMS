package Java8Practice;

import java.util.Arrays;
import java.util.stream.Stream;

public class StreamSortfindfirst
{

	public static void main(String[] args) 
	{
		 Stream.of("Ava", "Aneri" ,"Alberto")
		 .sorted()
		 .findFirst()
		 .ifPresent(System.out::println);
	
	  // Stream From Array ,Sort , filter and print
		 String [] names={"Ai" ,"Ankit" , " Kushal" , "Bent" , "Saika" , "amanda" , "Hans" , "Shivika" ,"Jaswik" ," Sree"};
		   Arrays.stream(names)
		          .filter(x->x.startsWith("J")).sorted().forEach(System.out::println);
	}

}
