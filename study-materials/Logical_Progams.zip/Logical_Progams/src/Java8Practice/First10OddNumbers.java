package Java8Practice;

import java.util.stream.IntStream;
import java.util.stream.Stream;

public class First10OddNumbers 
{

	public static void main(String[] args) 
	{
	  
	  IntStream.rangeClosed(1, 10).map(i->i+2).forEach(System.out::println);
      IntStream.range(1, Integer.MAX_VALUE)
      .filter(n->n%2!=0).limit(10).forEach(System.out::println);
	  
		
	}

}
