package Java8Practice;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class AgeofPerson
{

	public static void main(String[] args)
	{
	
		   LocalDate birthdate=LocalDate.of(1989, 10, 14); 
		   LocalDate today = LocalDate.now();
		   System.out.println( ChronoUnit.YEARS.between(birthdate, today));
		   long age= ChronoUnit.YEARS.between(birthdate, today); 
		   System.out.println("Age of Candiate is  : " +age);
		 	  
	}  
	  

}
