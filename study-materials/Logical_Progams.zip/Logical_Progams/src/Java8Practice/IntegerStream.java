package Java8Practice;

import java.util.stream.IntStream;

public class IntegerStream
{

	public static void main(String[] args)
	{
	   //IntStream.range(1, 20).forEach(System.out::println);
	   
	  // IntStream.range(1, 20).skip(5).forEach(System.out::println);
	   
	   int Number=   IntStream.range(1, 20).sum();
	     System.out.println(Number);
	   	   
	}

}
