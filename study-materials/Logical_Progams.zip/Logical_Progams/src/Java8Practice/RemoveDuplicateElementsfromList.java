package Java8Practice;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class RemoveDuplicateElementsfromList 
{

	public static void main(String[] args) 
	{
		/*
		 * List<String>
		 * listofStrings=Arrays.asList("Siva","Sekhar","Siva","Manvitha","Nandhu"
		 * ,"Jaswik", "Haripriya","Sekhar", "Nandhu"); List<String>
		 * UniqueStrings=listofStrings.stream().distinct().collect(Collectors.toList());
		 * System.out.println(UniqueStrings);
		 */ 
		
		
		 List<String> listofStrings1=Arrays.asList("SivaSekhar Hyderabad and Jaswik  Ramapuram");
		 List<String> UniqueStrings1=listofStrings1.stream().distinct().collect(Collectors.toList());
		 System.out.println(UniqueStrings1);
		 
	
	}

}
