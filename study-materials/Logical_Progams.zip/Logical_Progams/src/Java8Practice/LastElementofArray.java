package Java8Practice;

import java.util.Arrays;
import java.util.List;

public class LastElementofArray
{

	public static void main(String[] args) 
	{
	 List<String>  listofstrings=Arrays.asList("Siva","Sekhar", "Jaswik" ,"Sri" ,"Abhai" , "reddy");
	 
	 //find LastElement
	 String lastelement= listofstrings.stream().skip(listofstrings.size()-1).findFirst().get();
	 System.out.println(lastelement);
 
	 // Find FistElement
	 String Firstelement= listofstrings.stream().findFirst().get();
	 System.out.println(Firstelement);
	 
	 // Find 3rd Element
	 String TThirdElement=listofstrings.stream().skip(2).findFirst().get();
	 System.out.println(TThirdElement);
	 
	 		
	}

}
