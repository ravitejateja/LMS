package Java8Practice;

public class FibonacciSeries 
{

	public static void main(String[] args)
	{
        
	}

}
