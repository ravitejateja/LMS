package Java8Practice;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

public class CommonCharactersoftwostrings 
{

	public static void main(String[] args) 
	{
		String str="Siva Sekhar";
		String str1="Jasvik Sree";
		 str.chars().distinct().filter(ch->str1.indexOf(ch)!=-1).forEach(ch->System.out.print((char) ch)); 
		
		
		
			/*
			 * Set<Character> set1 =
			 * str.chars().mapToObj(c->(char)c).collect(Collectors.toSet()); Set<Character>
			 * set2 = str1.chars().mapToObj(c->(char)c).collect(Collectors.toSet());
			 * commonCharacters.retainAll(set2);
			 * System.out.println("Common characters is ==>" set1.retainAll(set2));
			 */	}

}
