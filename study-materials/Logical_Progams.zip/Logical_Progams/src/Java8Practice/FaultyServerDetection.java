package Java8Practice;
import java.util.HashMap;
import java.util.Map;

public class FaultyServerDetection
{

    public static int countFaults(int n, String[] logs) {
        Map<String, Integer> serverStatusCount = new HashMap<>();
        int replacements = 0;

        for (String log : logs) {
            String[] parts = log.split(" ");
            String serverId = parts[0];
            String status = parts[1];

            int count = serverStatusCount.getOrDefault(serverId, 0);
            if (status.equals("error")) {
                count++;
                serverStatusCount.put(serverId, count);
            } else {
                count = 0;
                serverStatusCount.put(serverId, count);
            }

            if (count >= 3) {
                replacements++;
                serverStatusCount.put(serverId, 0); // Reset count for replaced server
            }
        }

        return replacements;
    }

    public static void main(String[] args) {
        int n = 5;
        String[] logs = {"s1 error", "s2 error", "s1 error^prime prime", "s4 success", "s5 error", "s3 success", "s1 error"};
        System.out.println(countFaults(n, logs)); // Output:�1
����}
}