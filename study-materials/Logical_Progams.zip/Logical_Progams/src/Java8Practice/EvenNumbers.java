package Java8Practice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;


public class EvenNumbers
{

	public static void main(String[] args)
	{
	   List<Integer> list= Arrays.asList(1,3,4,6,8,9,2,12,43,56);
	   List<Integer> evennumbers = new ArrayList<Integer>();
	   for(int x:list)
	   {
		   if(x%2==0)
			   evennumbers.add(x);
	   }
	   
	   System.out.println("Even Numbes are " +evennumbers );
	  
	   // Using Java 8 Features.
	   
	   evennumbers= list.stream().filter(x->x%2==0).collect(Collectors.toList());
	   System.out.println("Even Numbes are " +evennumbers );
	   
	   //Print using Foreach Method 
	   
	   list.stream().filter(x->x%2==0).forEach(x->System.out.println(x));
	   list.stream().filter(x->x%2==0).forEach(System.out::println);
	}

}
