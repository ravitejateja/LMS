package Java8Practice;

import java.util.stream.Stream;

public class ReduceMethod
{

	public static void main(String[] args) 
	{
	   double total=Stream.of(7,5,6,7,8,9,1,3,4,5).reduce(0, (Integer a, Integer b)-> a+b);
	   System.out.println(total);
	}

}
