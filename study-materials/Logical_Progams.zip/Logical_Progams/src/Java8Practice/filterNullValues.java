package Java8Practice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class filterNullValues 
{

	public static void main(String[] args)
	{
        List<String> list=Arrays.asList("SCup" , null, "Bat","ball", null, "boundry" ,"bellon", null);
   	    List<String> list1= new ArrayList<String>();
   	      list1 = list.stream().filter(n->n!=null).collect(Collectors.toList());
   	      System.out.println(list1);
	
		 
	}

}
