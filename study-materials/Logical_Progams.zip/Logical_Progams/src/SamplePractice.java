
public class SamplePractice
{

	public static void main(String[] args)
	{
        int i, j,k, n=5;
		
		for( i=1; i<=n; i++)
		{
			
			for(j=n; j>=i ; j++)
			{
				System.out.print("* ");
			}
			System.out.println();
		}
		
	}

}
