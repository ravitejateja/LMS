package starPatternPrint;

public class InvertedPattern
{

	public static void main(String[] args)
	{
		        for (int i = 0; i  <  5; i++) 
		        {
		            // Print spaces
		            for (int j = 0; j  <  i; j++)
		            {
		                System.out.print(" ");
		            }
		            // Print asterisks
		            for (int k = i; k  <  5; k++)
		            {
		                System.out.print("* ");
		            }
		            System.out.println();
		        }
		    }
		
		   
		
	}


