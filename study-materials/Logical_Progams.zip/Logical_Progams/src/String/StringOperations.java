package String;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class StringOperations 
{

	public static void main(String[] args)
	{
        String str="Siva Sekhar Reddy Hyderabad";
      
        
        // 1. print the reverse of each word of the String 
        List<String> words=Arrays.asList(str.split(" "));
        Collections.reverse(words);
        String reverseorder=  words.stream().collect(Collectors.joining(" "));
        System.out.println(reverseorder);
        
       // 2. Set the Character at particulat index.
        StringBuilder sb= new StringBuilder(str);
         sb.setCharAt(6, 'M');
         System.out.println(sb);
        
                
	}

}
