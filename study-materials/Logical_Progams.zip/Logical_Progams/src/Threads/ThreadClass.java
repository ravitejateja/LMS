package Threads;

public class ThreadClass extends Thread
{
	
	public void run()
	{
		System.out.println("Chils Thread is Created");
	}

	public static void main(String[] args)
	{
        ThreadClass t=new ThreadClass();
         t.start();
         System.out.println("Main Thread is Ceated"); 
       
	}

}
