package Threads;

public class RunnableInterface  implements Runnable
{
    public void run()
    {
    	System.out.println("Runnable Inteface Implementation");
    }
	public static void main(String[] args)
	{
		
		RunnableInterface ri= new RunnableInterface();
		
		Thread t= new Thread(ri);
		t.start();
		System.out.println("Main thread is Executed");
		
   
	}

}
