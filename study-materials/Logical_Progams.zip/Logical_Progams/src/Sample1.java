
public class Sample1 
{

	public static void main(String[] args) 
	{
       StringBuffer sb= new StringBuffer("Complete");
       sb.setCharAt(1, 'i');
       sb.setCharAt(7, 'd');
       System.out.println(sb);
	}

}
