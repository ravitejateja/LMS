package NumbePatternPrint;

public class LeftsideNumincre
{

	public static void main(String[] args)
	{
		int i, j, n=8;
		for(i=1; i<=n ; i++)
		{
			for(j=1 ;j<=i ; j++)
			{
				System.out.print(i+ " ");
			}
			
			System.out.println();
		}
	}

}
