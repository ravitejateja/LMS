package NumbePatternPrint;

public class LeftSideNumberDec 
{

	public static void main(String[] args)
	{
		int i, j, n=8;
        for(i=n; i>=1 ;i--)
        {
        	for(j=1; j<=i ; j++)
        	{
        		System.out.print(j+ "  ");
        	}
        	System.out.println();
        }
	}

}
