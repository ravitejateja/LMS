package Filter;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

class Product
{
	int id;
	String name;
	double price;
	
	public Product(int id, String name,	double price)
	{
		this.id=id;
		this.name=name;
		this.price=price;
	}
}


public class FilterObject
{

	public static void main(String[] args) 
	{
        List<Product> productlist=new ArrayList();
        List<Product> productlis1t=new ArrayList();
        productlist.add(new Product(1, "Siva", 100.0));
        productlist.add(new Product(2, "Sekhar", 700.0));
        productlist.add(new Product(3, "Jaswik", 800.0));
        productlist.add(new Product(4, "Sri", 600.0));
        productlist.add(new Product(5, "Abhai", 1200.0));
        productlist.add(new Product(6, "Nandini", 1400.0));
        productlist.add(new Product(7, "Buddodu", 1500.0));
        productlist.add(new Product(8, "yuvaraj", 900.0));
        
        productlist.stream().filter(p->p.price>300).
        		forEach(p->System.out.println(p.price));
        
	}

}
