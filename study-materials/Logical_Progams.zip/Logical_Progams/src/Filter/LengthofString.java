package Filter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class LengthofString
{

	public static void main(String[] args)
	{
	  List<String> names= Arrays.asList("Siva","Sekha", "Jaswik", "Adbhai", "Sri", "Nandini");
	  List<String> names1=new ArrayList<>();
	  
	  names1=names.stream().filter(str->str.length() >2 & str.length()<4).collect(Collectors.toList());
	   System.out.println("names after the Condition is" + names1);
	   
	   //using Foreach method
	   names.stream().filter(str->str.length() >2 & str.length()<4).forEach(str->System.out.println(str));
	}

}
