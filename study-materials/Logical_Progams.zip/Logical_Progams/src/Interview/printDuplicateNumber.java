package Interview;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public class printDuplicateNumber 
{

	public static void main(String[] args) 
	{
          List<Integer> numbers = Arrays.asList(11,12,13,14,12,11,14,16);	
          
          numbers.stream().collect(Collectors.groupingBy(Function.identity(),Collectors.counting()))
                          .entrySet()
                          .stream()
                          .filter(entry->entry.getValue()>1).forEach(entry->System.out.println(entry.getKey()  + "-"  + entry.getValue()));
          
          
          
          
          

	}

}
