package Interview;

public class PeekMethod 
{

	public static void main(String[] args)
	{
          	

	}

}
