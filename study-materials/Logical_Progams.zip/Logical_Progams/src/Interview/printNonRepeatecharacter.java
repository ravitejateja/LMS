package Interview;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class printNonRepeatecharacter 
{
	
	public  Character findFirstNonRepeatChaacter(String input)
	{
		 
		 return input.chars().mapToObj(c->(char)c).collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new, Collectors.counting()))
		    		               .entrySet().stream().filter(entry->entry.getValue()==1).map(Map.Entry::getKey)
		    		               .findFirst()
		    		               .orElse(null);
	}

	public static void main(String[] args)
	{
		String input="Siva Sekhar Reddy";
		printNonRepeatecharacter print= new printNonRepeatecharacter();
		Character result = print.findFirstNonRepeatChaacter(input);
		if(result!=null)
		{
			System.out.println("First non-repeating chaacter :" +result);
		}
		else
		{
			System.out.println("No non-repeating character" + result);
		}
	}

}
