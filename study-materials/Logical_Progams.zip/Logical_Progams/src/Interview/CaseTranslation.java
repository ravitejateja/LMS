package Interview;

public class CaseTranslation 
{
     // Change capital to small and small letters in given String.
	public static void main(String[] args)
	{
		String str="SivA sEkHAr ReDdY";
		str.chars().mapToObj(c->(char)c)
		            .map(c->Character.isUpperCase(c) ? Character.toLowerCase(c) :Character.toUpperCase(c))
		            .map(String::valueOf)
		            .collect(Collectors.joining());
		            

	}

}
