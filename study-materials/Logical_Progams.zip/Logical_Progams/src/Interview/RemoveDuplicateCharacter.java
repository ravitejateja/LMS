package Interview;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.stream.Collectors;

public class RemoveDuplicateCharacter
{

	public static void main(String[] args) 
	{
		String input="CHEDSAFESHJGSTEFASETS";
		
		
		String result=input.chars()  // Convert to IntStream
				       .mapToObj(c->(char)c)  // Convert to Stream<Character>
				       .collect(Collectors.toCollection(LinkedHashSet::new))   // Collect to LinkedHashSet to maintain order and remove duplicates 
				       .stream()  // Stream the LinkedHashSet
				       .map(String::valueOf)  // Convert to Stream<String>
				       .collect(Collectors.joining()); // Join to form a single string
                        System.out.println(result); // Output: CHEDSAFJGTS
        
		
	}

}
