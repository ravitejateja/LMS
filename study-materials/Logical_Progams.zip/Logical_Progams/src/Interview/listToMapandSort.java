package Interview;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class listToMapandSort
{

	public static void main(String[] args)
	{
        List<String>  items=Arrays.asList("paint-53", "shirt-30", "shoes-19", "tux-33", "apr-40");
        
        // Convert list to map with reversed key-value pairs.
       Map<Object, Object> resultmap = items.stream().map(item->item.split("-"))
        .collect(Collectors.toMap(parts->parts[1], parts->parts[0]));
       
       System.out.print(resultmap);
       
       // sort the map based on key and collect into a LinkedHashmap to maintain order.
       
		/*
		 * Map<String, String> sortedmap=resultmap.entrySet() .stream()
		 * .sorted(Map.Entry.comparingByKey()) .collect(Collectors.toMap(
		 * Map.Entry::getKey, Map.Entry::getValue, (oldValue,newValue)->oldValue,
		 * LinkedHashMap::new
		 * 
		 * 
		 * ));
		 */	
	}

}
