package Interview;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

// print the character A12B23C21 , no of times the number beside to that character.
public class printCharacterNoOfTimes 
{

	public static void main(String[] args)
	{
	   String input="A21B13C32";
	   
	   // Regular Expression to match character followed by one or more digits.
	   Pattern pattern=Pattern.compile("([A-Za-z])(\\d+)");
	   Matcher matcher =pattern.matcher(input);
	   
	   // process each match
	    StringBuilder result= new StringBuilder();
	    while(matcher.find())
	    {
	    	char character = matcher.group(1).charAt(0);
	    	int count =Integer.parseInt(matcher.group(2));
	    	result.append(repeatCharacter(character, count));
	    }
	              // print the result.
               System.out.println(result.toString());
	}          
	          
	     // Helper method to repeat a character a given number of times.
	    	private static String repeatCharacter(char character, int count) 
	    	{
	    		StringBuilder repeated = new StringBuilder();
	    		for(int i=0 ; i<count ; i++)
	    		{
	    			repeated.append(character);
	    		}
	    			return repeated.toString();
	      }	
	
}
