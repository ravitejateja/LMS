package Interview;

import java.util.Arrays;

public class SumOfIntegers
{
     // Find the sum of Integers for even numbers of  Arrays.
	public static void main(String[] args) 
	{
            int a[]= {1,3,5,6,7,9,12,14,15,16,17};
           int result = Arrays.stream(a).filter(n->n%2==0).sum();
           System.out.println(result);
		   
	}

}
