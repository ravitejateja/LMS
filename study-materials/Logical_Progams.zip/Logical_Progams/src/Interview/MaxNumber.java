package Interview;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import InterviewRealTimeByJava8.Employee;

public class MaxNumber 
{

	public static void main(String[] args) 
	{
        var Number= Arrays.asList(1,4,2,8,4,9,12,34,12,67,86,34,12,34);
		
        var result=  Number.stream().max(Integer::compareTo);
        var result1= Number.stream().min(Integer::compareTo);
        System.out.println(result);
        System.out.println(result1);
        
        // find nth Highest number (a,b)->b-a means Descending Order
        // (a,b)->a-b means Ascending Order.
        
       var result2 = Number.stream().distinct().sorted((a,b)->a-b).skip(2).findFirst();
         System.out.println(result2);
		// Number.stream().collect(Collectors.maxBy(Comparator.comparingDouble(Employee::getSalary)));
			
	}
}
