package Interview;

import java.util.Arrays;
import java.util.stream.IntStream;


// Find the Missing Number in the given Array.given numbers are in the range from 10 to 15 only.
public class findMissingNumber
{

	public static void main(String[] args)
	{
        int start =10;
        int end =15;
        int sum= IntStream.rangeClosed(start, end).sum();
        
          System.out.println(sum);
        
          Integer[] numbers= {10,11,12,14,15};
          long count=  Arrays.stream(numbers).mapToInt(Integer::intValue).sum(); 	
          System.out.println("Count for the given nUmbers is :" +count);
		
          long  result =sum-count;
          System.out.println("Missing number is :" +result);
	}

}
