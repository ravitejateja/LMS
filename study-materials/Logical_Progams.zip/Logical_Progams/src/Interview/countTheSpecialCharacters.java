package Interview;

import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class countTheSpecialCharacters 
{

	public static void main(String[] args) 
	{
		String specialCharacters = "!@#$%^&*()_+{}|:<>?~`-=[]\\;',./\"";
        String str="abg@@%dodkk%&@s";
        
         Map<Character, Long> str1 = str.chars()
                                        .mapToObj(n->(char)n)
                                        .filter(c->specialCharacters.indexOf(c)>=0)
                                        .collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
         
                  System.out.println(str1);
	}    

}
