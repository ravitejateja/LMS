package Interview;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class SecondHighestNumber
{

	public static void main(String[] args) 
	{
    
		  int temp, size;
		  int array[] = {10,23,35,4,5,26,17,88,99,6,9,2,3,1};
		  size=array.length;
		  for(int i=0; i<size;  i++)
		  {
			  for(int j=0 ; j<size; j++)
			  {
				  if(array[i]>array[j])
				  {
					   temp=array[i];
					   array[i]=array[j];
					   array[j]=temp;
				  }
			  }
			  
			  List<Integer> numbers=Arrays.asList(10,23,35,4,5,26,17,88,99,6,9,2,3,1);
			Optional<Integer> HighestNumber = numbers.stream().sorted(Comparator.reverseOrder())
			                  .distinct()
			                  .skip(1)
			                  .findFirst();
			  System.out.println(HighestNumber.get());
			  
			  
		  }
		
		 // System.out.println("Second Highest Number is :" +array[size-8]);
	}

}
