package Interview;

public class sumOfConsequtiveNumbers 
{

	public static void main(String[] args) 
	{
      int a[] = {1,2,4,5,6,8,4,1};
      int sum =0;
      
      for(int i=0; i<=a.length-1 ;i++)
      {
    	   sum+=a[i];
    	  System.out.println(sum);
      }

	}

}
