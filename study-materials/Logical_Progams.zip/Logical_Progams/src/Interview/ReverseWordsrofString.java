package Interview;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class ReverseWordsrofString
{

	public static void main(String[] args)
	{
		
		String str="Siva Sekhar Reddy Hyderabad";
		 // 1. print the reverse of each word of the String 
        List<String> words=Arrays.asList(str.split(" "));
        Collections.reverse(words);
        String reverseorder=  words.stream().collect(Collectors.joining(" "));
        System.out.println(reverseorder);
       
	}

}
