package Interview;

public class StringReverse 
{

	public static void main(String[] args) 
	{
		 String str="Siva Sekhar Reddy";
	     char ch;   
	     String str1 ="";
		 
		 
	        for(int i=0 ; i<str.length() ; i++)
	        {
	           ch=str.charAt(i); 
	           str1=ch+str1;
	        }
	        
	        System.out.println(str1);
	

	}

}
