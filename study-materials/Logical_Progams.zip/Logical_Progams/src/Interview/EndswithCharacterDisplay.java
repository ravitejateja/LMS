package Interview;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class EndswithCharacterDisplay 

{
	  // get the list in each String ends with "ia";

	public static void main(String[] args)
	{
        List<String> list= Arrays.asList("China", "Japan", "America", "India" , "Indonesia");
        
       List<String> list1 = list.stream()
        .filter(i->i.endsWith("ia")).collect(Collectors.toList());
       System.out.println(list1);
	}

}
