package Interview;

public class totalCountOfString 
{
   // Count the no of Characters.
	public static void main(String[] args) 
	{
        String str= "Siva Sekhar Reddy";
         long count = str.chars().count();
         System.out.println(count);

	}

}
