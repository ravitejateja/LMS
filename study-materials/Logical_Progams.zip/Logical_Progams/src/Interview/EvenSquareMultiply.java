package Interview;

import java.util.Arrays;
import java.util.List;

public class EvenSquareMultiply 
{
   // Print the resluts get even number and then Square the number and then multiply that number prit the result.
	public static void main(String[] args)
	{
	    List<Integer> list=Arrays.asList(8,19,21,4,6);
	    list.stream().filter(i->i%2==0)
	    .map(i->i*i)
	    .map(i->i*i)
	    .forEach(System.out::println);
	}

}
