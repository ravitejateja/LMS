import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Sample11 
{
	
	public static void main(String[] args)
	{
		String str=new String("Siva");
		String str1=new String("Siva");
		
		System.out.println(str==str1);	
		System.out.println(str1.equals(str));
	}
      
}


