
public class SingletonLazyIntialization
{
  private static SingletonLazyIntialization instance =null ;
  private SingletonLazyIntialization()
  {
	  
  };
  
  public static SingletonLazyIntialization getInstance()
  {
	  if(instance==null)
	  {
		  instance=new SingletonLazyIntialization();
	  }
	  return instance;
  }
  
	
}
