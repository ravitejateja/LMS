package Collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;

public class Sample
{

	public static void main(String[] args)
	{

		/*
		 * List<String> list =new ArrayList<>(); list.add("Java"); list.add("DBMS");
		 * list.add("Python"); list.add("Selenium"); System.out.println(list.get(1));
		 */
		    
		
		/*
		 * Set<Integer> set=new HashSet<>(); set.add(1); set.add(2); set.add(4);
		 * set.add(3); System.out.println(set.size());
		 */    
		    
		
		
		/*
		 * Map<String, Integer> map= new HashMap<>(); map.put("Alice", 30);
		 * map.put("Bob", 20); map.put("Alice", 35);
		 * System.out.println(map.get("Alice"));
		 */
		
		
		
		/*
		 * List<String> list=Arrays.asList("A","B","C","D"); for(String s: list) {
		 * System.out.print(s + " "); }
		 */
		
		
		
		/*
		 * Queue<Integer> queue= new LinkedList<>(); queue.add(1); queue.add(2);
		 * queue.add(3); queue.add(4); System.out.println(queue.peek());
		 */
		
		
		
		/*
		 * List<Integer> list= new ArrayList<>(Arrays.asList(1,2,3,4,5,6,7));
		 * list.removeIf(n->n%2==0); System.out.println(list);
		 */
		
		/*
		 * List<Integer> list = new ArrayList<>(); list.add(1); list.add(2);
		 * list.add(3); list.add(1,4); System.out.println(list);
		 */
		
		/*
		 * Queue<String> queue=new PriorityQueue<>(); queue.offer("C");
		 * queue.offer("B"); queue.offer("A"); System.out.println(queue);
		 */
		
		
		/*
		 * List<Integer> list = new ArrayList<>(); for(int i=1; i <=5; i++) {
		 * list.add(i); }
		 * 
		 * System.out.println(list); list.set(2, 10); System.out.println(list);
		 */
		
		
		
		
		
	}

}
