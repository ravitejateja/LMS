package Collections;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class ListtoMapConversion
{

	public static void main(String[] args)
	{
         List<Integer> list=new ArrayList<>();
         list.add(10);
         list.add(20);
         list.add(30);
         list.add(40);
         list.add(50);
         list.add(90);
         System.out.println(list);
         
         Map<Integer, Integer>  map= new HashMap<>();
         
         for (int i = 0; i < list.size() ; i++) 
         {
              map.put(i, list.get(i));			
		 }
         
         System.out.println("List to Map : " );
         map.forEach((index , value)->System.out.println(index + "->" +value));;
         
         
		}
		 
	}


