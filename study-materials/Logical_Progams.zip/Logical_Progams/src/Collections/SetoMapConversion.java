package Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class SetoMapConversion 
{

	public static void main(String[] args) 
	{
		Set<String> set = new HashSet<>();
		set.add("Siva");
		set.add("Jaswik");
		set.add("Sree");
		set.add("Abhai");
		set.add("Sekhar");
		set.add("Reddy");
		
		System.out.println("set values is :"  +set);
		
		System.out.println("Map values is");
		
		/*
		 * Map<Integer, Integer> map= new HashMap<>();
		 * 
		 * int key =1;
		 * 
		 * for (String value : set) { map.put(key ++, value); }
		 * System.out.println("List to Map : " ); map.forEach((index ,
		 * value)->System.out.println(index + "->" +value));;
		 */ 
         
         
        Map<String, Integer> map1 = set.stream()
        		                        .collect(Collectors.toMap(key->key, value->value.length()))
        		                        .forEach(key , value)->System.out.println(key +":" + value);

	}

}
