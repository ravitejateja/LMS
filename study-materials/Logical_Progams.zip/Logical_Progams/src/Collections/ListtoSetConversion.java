package Collections;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ListtoSetConversion 
{

	public static void main(String[] args) 
	{

		List<Integer> list=new ArrayList<>();
        list.add(10);
        list.add(20);
        list.add(30);
        list.add(40);
        list.add(50);
        list.add(90);
        System.out.println(list);
        
        
        System.out.println("Set Conversion is: ");
        Set<Integer> set= new HashSet<>();
        set.addAll(list);
        System.out.println(set);
        
	}

}
