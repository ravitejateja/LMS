package Map;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class NamestoUpperCase
{

	public static void main(String[] args)
	{
		List<String> Vehicles=Arrays.asList("tvs","Suzuki","Maruti" ,"Bajaj" ,"Yamaha","Elon");
		List<String> Vehicles1=new ArrayList<>();
		Vehicles1=Vehicles.stream().map(v->v.toUpperCase()).collect(Collectors.toList());
		System.out.println(Vehicles1);
		Vehicles.stream().map(v->v.toUpperCase()).forEach(v->System.out.println(v));
		
		
	}

}
