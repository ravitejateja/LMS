package Map;

import java.util.Arrays;
import java.util.List;

public class MultipyNumber
{

	public static void main(String[] args)
	{
	   List<Integer> numbers=Arrays.asList(1,3,5,6,7,9,21,2,8);
	   for(int n: numbers)
	   {
		   System.out.println(n*2);
	   }
	   
	   //Using Java 8
	    numbers.stream().map(n->n*2).forEach(p->System.out.println(p));
	}

}
