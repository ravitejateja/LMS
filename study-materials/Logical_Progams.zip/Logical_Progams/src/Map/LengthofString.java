package Map;

import java.util.Arrays;
import java.util.List;

public class LengthofString 
{

	public static void main(String[] args) 
	{
		List<String> Vehicles=Arrays.asList("tvs","Suzuki","Maruti" ,"Bajaj" ,"Yamaha","Elon");
		for(String name: Vehicles)
		{
			System.out.println( name  +  "  " +   name.length());
		}
		
		Vehicles.stream().map(vname->vname.length()).forEach(len->System.out.println(len));
	}

}
