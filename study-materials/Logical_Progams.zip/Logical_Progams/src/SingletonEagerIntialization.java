
public class SingletonEagerIntialization 
{
  private SingletonEagerIntialization()
	{
		
	  
	}
	private static final SingletonEagerIntialization instance= new SingletonEagerIntialization();
	public static SingletonEagerIntialization getInstance()
	{
		return instance;
	}
}
	

