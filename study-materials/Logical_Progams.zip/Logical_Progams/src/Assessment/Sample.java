package Assessment;

import java.util.Arrays;

public class Sample 
{

	public static void main(String[] args)
	{
      int nums[] = {1,2,3,4,5,6};
      Arrays.stream(nums).filter(n->n%3==0 || n%5==0 ).forEach(n->System.out.println(n));
	}

}
