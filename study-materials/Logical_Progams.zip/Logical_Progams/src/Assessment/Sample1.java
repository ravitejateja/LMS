package Assessment;

import java.util.ArrayList;

public class Sample1
{

	public static void main(String[] args) 
	{
       ArrayList<Integer> marks = new ArrayList<>();
       marks.add(78);
       marks.add(45);
       marks.add(91);
       marks.add(21);
       marks.add(30);
       marks.add(48);
       marks.add(36);
       
       
       marks.sort((y,x)->{(x-y)});  // compiletime error
       System.out.println("After Sorting into order the output is:");
       marks.forEach(x->System.out.println(x));       
       
       
		
	}

}
