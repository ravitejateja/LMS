import java.util.PriorityQueue;

public class MaximumScore {
    
    public static long getMaximumScore(int[] arr, int k) {
        long score = 0;
        PriorityQueue<Pair> maxHeap = new PriorityQueue<>((a, b) -> Long.compare(b.value, a.value));
        
        for (int i = 0; i < arr.length; i++) {
            maxHeap.offer(new Pair(i, arr[i]));
        }
        
        for (int i = 0; i < k; i++) {
            Pair maxPair = maxHeap.poll();
            score += maxPair.value;
            if (maxPair.index > 0) {
                int[] leftPartition = new int[maxPair.index];
                int[] rightPartition = new int[arr.length - maxPair.index - 1];
                System.arraycopy(arr, 0, leftPartition, 0, maxPair.index);
                System.arraycopy(arr, maxPair.index + 1, rightPartition, 0, arr.length - maxPair.index - 1);
                arr = (sum(leftPartition) > sum(rightPartition)) ? leftPartition : rightPartition;
            } else {
                arr = new int[0];
            }
        }
        
        return score;
    }
    
    private static long sum(int[] arr) {
        long sum = 0;
        for (int num : arr) {
            sum += num;
        }
        return sum;
    }
    
    static class Pair {
        int index;
        int value;
        
        Pair(int index, int value) {
            this.index = index;
            this.value = value;
        }
    }
    
    
    public static void main(String[] args)
    {
    	int[] arr = {-5, 4, -10, -1, -5, 8, -3}; 
    	   int k = 3;
    	   System.out.print(arr, k); 
	}
       
}