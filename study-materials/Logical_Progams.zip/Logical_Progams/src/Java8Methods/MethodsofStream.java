package Java8Methods;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class MethodsofStream
{

	public static void main(String[] args)
	{
	  List<Integer> numbers=Arrays.asList(1,2,3,4,5,6,7,8,9,12,23,34,56,67,89,45);
	  
	  
	 // Count() Method 
	 long evencount= numbers.stream().filter(n->n%2==0).count();
	 System.out.println(evencount);
	 
	 // Min() method 
	Optional<Integer> min= numbers.stream().min((val1,val2)->{
		                                   return val1.compareTo(val2);
			                            });
	
	  System.out.println(min.get());
	  
	  // MAax() value 
	 Optional<Integer> max= numbers.stream().max((a,b)->{
		                             return a.compareTo(b);
	                               });
	 System.out.println(max.get());
	  
	  }
	 }
	


