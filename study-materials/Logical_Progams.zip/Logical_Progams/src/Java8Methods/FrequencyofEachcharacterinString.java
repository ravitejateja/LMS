package Java8Methods;

import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class FrequencyofEachcharacterinString {

	public static void main(String[] args) {
		String inputString = "Siva Sekhar Reddy Annapureddy";
		Map<Character, Long> charCountMap = inputString.chars().mapToObj(c -> (char) c)
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		System.out.println(charCountMap);

		inputString.chars() // Convert String IntStream
				.mapToObj(c -> (char) c) // convert each Intstream to a char

				.collect(Collectors.groupingBy(c -> c, Collectors.counting())) // Group by character and count them
				.forEach((character, frequency) -> System.out.print(character + " ; " + frequency)); // print the
	}

}
