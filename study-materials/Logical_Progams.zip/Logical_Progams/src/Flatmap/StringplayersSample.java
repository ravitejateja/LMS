package Flatmap;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StringplayersSample 
{

	public static void main(String[] args)
	{
		List<String> list  = Arrays.asList("Siva","Sekhar","Reddy");
		List<String> list1 = Arrays.asList("Jaswik","Sree","Abhai");
		List<String> list2 = Arrays.asList("Giddalur","Chennai","Hyderabd");
		
		List<List<String>> playeslist=Arrays.asList(list,list1,list2);
		
		for(List<String>players:playeslist)
		{
			for(String name:players)
			{
				System.out.println(name);
			}
		}
		
		// using Streams flatmap
		List<String> finallist= playeslist.stream().flatMap(plist->plist.stream()).collect(Collectors.toList());
		System.out.println(finallist);
	}

}
