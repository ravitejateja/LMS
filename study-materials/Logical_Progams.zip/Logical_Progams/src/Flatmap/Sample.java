package Flatmap;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Sample
{

	public static void main(String[] args)
	{
	  List<Integer> list =Arrays.asList(1,2,4);
	  List<Integer> list1=Arrays.asList(5,6,7);
	  List<Integer> list2=Arrays.asList(8,9,10);
	  
	  List<List<Integer>> finallist=Arrays.asList(list,list1,list2);
	  List<Integer> originallist=new ArrayList<>();
	  
	  originallist=finallist.stream().flatMap(x->x.stream().map(n->n+10)).collect(Collectors.toList());
	  System.out.println(originallist);
	  
	  
	  
	  
	}

}
