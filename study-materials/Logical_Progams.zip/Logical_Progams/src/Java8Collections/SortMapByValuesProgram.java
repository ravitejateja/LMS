package Java8Collections;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

public class SortMapByValuesProgram 
{

	public static void main(String[] args)
	{
        Map<Integer, String> idNameMap= new HashMap<>();
        idNameMap.put(123, "Siva");
        idNameMap.put(156, "Sekhar");
        idNameMap.put(234, "Jasvik");
        idNameMap.put(896, "Sree");
        idNameMap.put(462, "Reddy");
        
        
      Map<Integer, String> sortedIdNameMap =  idNameMap.entrySet()
                 .stream()
                 .sorted(Entry.comparingByValue())
                 .collect(Collectors.toMap(Entry::getKey, Entry::getValue,(e1,e2)->e1,LinkedHashMap::new));
      
      
      System.out.println(" Befor Sorting the Map :");
      System.out.println(idNameMap);
      System.out.println("After Sorting the Map  : ");
      System.out.println(sortedIdNameMap);
		
	}

}
