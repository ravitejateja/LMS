import java.util.Comparator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Stream;

public class Test
{

	public static void main(String[] args)
	{
      Map<Integer, String>  map=new ConcurrentHashMap<>();
      map.put(1, "Siva");
      map.put(2, "Sekhar");
      map.put(3, "Hyd"); 
      map.put(4, "Chennai");
      map.put(5, "Hyds");
     // map.forEach((index, value)->System.out.println(index + "->" +value));
     // map.forEach((index , value)->System.out.println(index + "->" +value));;
      
      String str="Jasvik Sree Abhai Simha Reddy";
      System.out.println(str.charAt(9));
      
	}

}
