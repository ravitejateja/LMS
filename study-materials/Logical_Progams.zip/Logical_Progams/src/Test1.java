import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class Test1
{

	public static void main(String[] args) 
	{
		int a[] = {10, 14, 23, 25, 30};
		 int result = Arrays.stream(a).filter(n->n%2==0).sum();
		 System.out.println(result);
	} 

}
