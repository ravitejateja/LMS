package LogicalPrograms;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import jdk.internal.misc.FileSystemOption;

public class PyramidOfNumbers 
{

	public static void main(String[] args)
	{
		While(n<)	
		
	}

}
